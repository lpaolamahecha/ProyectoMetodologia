﻿
namespace wCaminoMinimoIO
{
    partial class frmDijkstra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.CasaComercial = new System.Windows.Forms.PictureBox();
            this.CasaGris = new System.Windows.Forms.PictureBox();
            this.Mansion = new System.Windows.Forms.PictureBox();
            this.CasaPlus = new System.Windows.Forms.PictureBox();
            this.CasaPurpura = new System.Windows.Forms.PictureBox();
            this.CasaSeria = new System.Windows.Forms.PictureBox();
            this.CasaSol = new System.Windows.Forms.PictureBox();
            this.Casita = new System.Windows.Forms.PictureBox();
            this.Encantada = new System.Windows.Forms.PictureBox();
            this.Policia = new System.Windows.Forms.PictureBox();
            this.Tienda = new System.Windows.Forms.PictureBox();
            this.Banco = new System.Windows.Forms.PictureBox();
            this.Cafe = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox33 = new System.Windows.Forms.PictureBox();
            this.pictureBox34 = new System.Windows.Forms.PictureBox();
            this.pictureBox35 = new System.Windows.Forms.PictureBox();
            this.pictureBox36 = new System.Windows.Forms.PictureBox();
            this.pictureBox37 = new System.Windows.Forms.PictureBox();
            this.pictureBox38 = new System.Windows.Forms.PictureBox();
            this.pictureBox40 = new System.Windows.Forms.PictureBox();
            this.pictureBox42 = new System.Windows.Forms.PictureBox();
            this.pictureBox43 = new System.Windows.Forms.PictureBox();
            this.pictureBox44 = new System.Windows.Forms.PictureBox();
            this.pictureBox45 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.De1a2 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.De2a3 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.De12a13 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.De12a11 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.De10a9 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.De11a9 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.De6a9 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.De1a12 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.De11a10 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.De7a8 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.De4a8 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.De3a6 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.De3a5 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.De6a4 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.De11a6 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.De2a11 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btnCaminoMin = new System.Windows.Forms.Button();
            this.De6a8 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblValida = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.lblRuta = new System.Windows.Forms.Label();
            this.lblPtoLlegada = new System.Windows.Forms.Label();
            this.lblPtoPartida = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CasaComercial)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CasaGris)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Mansion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CasaPlus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CasaPurpura)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CasaSeria)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CasaSol)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Casita)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Encantada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Policia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tienda)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Banco)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cafe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar;
            this.pictureBox3.Location = new System.Drawing.Point(185, 63);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(201, 50);
            this.pictureBox3.TabIndex = 14;
            this.pictureBox3.TabStop = false;
            // 
            // CasaComercial
            // 
            this.CasaComercial.Image = global::wCaminoMinimoIO.Properties.Resources.CasaComercial;
            this.CasaComercial.Location = new System.Drawing.Point(1116, 397);
            this.CasaComercial.Name = "CasaComercial";
            this.CasaComercial.Size = new System.Drawing.Size(135, 98);
            this.CasaComercial.TabIndex = 13;
            this.CasaComercial.TabStop = false;
            this.CasaComercial.Click += new System.EventHandler(this.CasaComercial_Click);
            // 
            // CasaGris
            // 
            this.CasaGris.Image = global::wCaminoMinimoIO.Properties.Resources.CasaGris;
            this.CasaGris.Location = new System.Drawing.Point(86, 330);
            this.CasaGris.Name = "CasaGris";
            this.CasaGris.Size = new System.Drawing.Size(101, 90);
            this.CasaGris.TabIndex = 12;
            this.CasaGris.TabStop = false;
            this.CasaGris.Click += new System.EventHandler(this.CasaGris_Click);
            // 
            // Mansion
            // 
            this.Mansion.Image = global::wCaminoMinimoIO.Properties.Resources.CasaLujo;
            this.Mansion.Location = new System.Drawing.Point(615, 53);
            this.Mansion.Name = "Mansion";
            this.Mansion.Size = new System.Drawing.Size(151, 66);
            this.Mansion.TabIndex = 11;
            this.Mansion.TabStop = false;
            this.Mansion.Click += new System.EventHandler(this.Mansion_Click);
            // 
            // CasaPlus
            // 
            this.CasaPlus.Image = global::wCaminoMinimoIO.Properties.Resources.CasaPlus;
            this.CasaPlus.Location = new System.Drawing.Point(876, 292);
            this.CasaPlus.Name = "CasaPlus";
            this.CasaPlus.Size = new System.Drawing.Size(152, 79);
            this.CasaPlus.TabIndex = 10;
            this.CasaPlus.TabStop = false;
            this.CasaPlus.Click += new System.EventHandler(this.CasaPlus_Click);
            // 
            // CasaPurpura
            // 
            this.CasaPurpura.Image = global::wCaminoMinimoIO.Properties.Resources.CasaPurpura;
            this.CasaPurpura.Location = new System.Drawing.Point(918, 53);
            this.CasaPurpura.Name = "CasaPurpura";
            this.CasaPurpura.Size = new System.Drawing.Size(145, 82);
            this.CasaPurpura.TabIndex = 9;
            this.CasaPurpura.TabStop = false;
            this.CasaPurpura.Click += new System.EventHandler(this.CasaPurpura_Click);
            // 
            // CasaSeria
            // 
            this.CasaSeria.Image = global::wCaminoMinimoIO.Properties.Resources.CasaSeria;
            this.CasaSeria.Location = new System.Drawing.Point(514, 448);
            this.CasaSeria.Name = "CasaSeria";
            this.CasaSeria.Size = new System.Drawing.Size(101, 103);
            this.CasaSeria.TabIndex = 8;
            this.CasaSeria.TabStop = false;
            this.CasaSeria.Click += new System.EventHandler(this.CasaSeria_Click);
            // 
            // CasaSol
            // 
            this.CasaSol.Image = global::wCaminoMinimoIO.Properties.Resources.CasaSol;
            this.CasaSol.Location = new System.Drawing.Point(757, 464);
            this.CasaSol.Name = "CasaSol";
            this.CasaSol.Size = new System.Drawing.Size(99, 99);
            this.CasaSol.TabIndex = 7;
            this.CasaSol.TabStop = false;
            this.CasaSol.Click += new System.EventHandler(this.CasaSol_Click);
            // 
            // Casita
            // 
            this.Casita.Image = global::wCaminoMinimoIO.Properties.Resources.Casita;
            this.Casita.Location = new System.Drawing.Point(386, 43);
            this.Casita.Name = "Casita";
            this.Casita.Size = new System.Drawing.Size(112, 100);
            this.Casita.TabIndex = 6;
            this.Casita.TabStop = false;
            this.Casita.Click += new System.EventHandler(this.Casita_Click);
            // 
            // Encantada
            // 
            this.Encantada.Image = global::wCaminoMinimoIO.Properties.Resources.Encantada;
            this.Encantada.Location = new System.Drawing.Point(88, 470);
            this.Encantada.Name = "Encantada";
            this.Encantada.Size = new System.Drawing.Size(100, 99);
            this.Encantada.TabIndex = 5;
            this.Encantada.TabStop = false;
            this.Encantada.Click += new System.EventHandler(this.Encantada_Click);
            // 
            // Policia
            // 
            this.Policia.Image = global::wCaminoMinimoIO.Properties.Resources.Policia;
            this.Policia.Location = new System.Drawing.Point(386, 331);
            this.Policia.Name = "Policia";
            this.Policia.Size = new System.Drawing.Size(92, 92);
            this.Policia.TabIndex = 4;
            this.Policia.TabStop = false;
            this.Policia.Click += new System.EventHandler(this.Policia_Click);
            // 
            // Tienda
            // 
            this.Tienda.Image = global::wCaminoMinimoIO.Properties.Resources.Tienda;
            this.Tienda.Location = new System.Drawing.Point(1090, 43);
            this.Tienda.Name = "Tienda";
            this.Tienda.Size = new System.Drawing.Size(135, 103);
            this.Tienda.TabIndex = 3;
            this.Tienda.TabStop = false;
            this.Tienda.Click += new System.EventHandler(this.Tienda_Click);
            // 
            // Banco
            // 
            this.Banco.Image = global::wCaminoMinimoIO.Properties.Resources.Banco;
            this.Banco.Location = new System.Drawing.Point(757, 129);
            this.Banco.Name = "Banco";
            this.Banco.Size = new System.Drawing.Size(101, 103);
            this.Banco.TabIndex = 1;
            this.Banco.TabStop = false;
            this.Banco.Click += new System.EventHandler(this.Banco_Click);
            // 
            // Cafe
            // 
            this.Cafe.Image = global::wCaminoMinimoIO.Properties.Resources.Cafe;
            this.Cafe.Location = new System.Drawing.Point(86, 42);
            this.Cafe.Name = "Cafe";
            this.Cafe.Size = new System.Drawing.Size(102, 101);
            this.Cafe.TabIndex = 0;
            this.Cafe.TabStop = false;
            this.Cafe.Click += new System.EventHandler(this.Cafe_Click);
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar1;
            this.pictureBox17.Location = new System.Drawing.Point(401, 232);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(100, 50);
            this.pictureBox17.TabIndex = 17;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar1;
            this.pictureBox18.Location = new System.Drawing.Point(401, 281);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(100, 50);
            this.pictureBox18.TabIndex = 18;
            this.pictureBox18.TabStop = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandarL;
            this.pictureBox19.Location = new System.Drawing.Point(416, 420);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(100, 103);
            this.pictureBox19.TabIndex = 19;
            this.pictureBox19.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar;
            this.pictureBox20.Location = new System.Drawing.Point(185, 353);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(201, 50);
            this.pictureBox20.TabIndex = 20;
            this.pictureBox20.TabStop = false;
            // 
            // pictureBox22
            // 
            this.pictureBox22.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar;
            this.pictureBox22.Location = new System.Drawing.Point(478, 353);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(201, 50);
            this.pictureBox22.TabIndex = 22;
            this.pictureBox22.TabStop = false;
            // 
            // pictureBox23
            // 
            this.pictureBox23.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar1;
            this.pictureBox23.Location = new System.Drawing.Point(770, 414);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(100, 50);
            this.pictureBox23.TabIndex = 23;
            this.pictureBox23.TabStop = false;
            // 
            // pictureBox21
            // 
            this.pictureBox21.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar1;
            this.pictureBox21.Location = new System.Drawing.Point(102, 420);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(100, 50);
            this.pictureBox21.TabIndex = 21;
            this.pictureBox21.TabStop = false;
            // 
            // pictureBox24
            // 
            this.pictureBox24.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar1;
            this.pictureBox24.Location = new System.Drawing.Point(770, 281);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(100, 50);
            this.pictureBox24.TabIndex = 24;
            this.pictureBox24.TabStop = false;
            // 
            // pictureBox25
            // 
            this.pictureBox25.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar1;
            this.pictureBox25.Location = new System.Drawing.Point(770, 232);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(100, 50);
            this.pictureBox25.TabIndex = 25;
            this.pictureBox25.TabStop = false;
            // 
            // pictureBox26
            // 
            this.pictureBox26.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar;
            this.pictureBox26.Location = new System.Drawing.Point(496, 63);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(119, 50);
            this.pictureBox26.TabIndex = 26;
            this.pictureBox26.TabStop = false;
            // 
            // pictureBox27
            // 
            this.pictureBox27.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandarL;
            this.pictureBox27.Location = new System.Drawing.Point(662, 118);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(100, 103);
            this.pictureBox27.TabIndex = 27;
            this.pictureBox27.TabStop = false;
            // 
            // pictureBox29
            // 
            this.pictureBox29.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandarL;
            this.pictureBox29.Location = new System.Drawing.Point(929, 367);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(100, 103);
            this.pictureBox29.TabIndex = 29;
            this.pictureBox29.TabStop = false;
            // 
            // pictureBox33
            // 
            this.pictureBox33.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar1;
            this.pictureBox33.Location = new System.Drawing.Point(102, 137);
            this.pictureBox33.Name = "pictureBox33";
            this.pictureBox33.Size = new System.Drawing.Size(67, 50);
            this.pictureBox33.TabIndex = 33;
            this.pictureBox33.TabStop = false;
            // 
            // pictureBox34
            // 
            this.pictureBox34.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar1;
            this.pictureBox34.Location = new System.Drawing.Point(102, 182);
            this.pictureBox34.Name = "pictureBox34";
            this.pictureBox34.Size = new System.Drawing.Size(67, 50);
            this.pictureBox34.TabIndex = 34;
            this.pictureBox34.TabStop = false;
            // 
            // pictureBox35
            // 
            this.pictureBox35.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar1;
            this.pictureBox35.Location = new System.Drawing.Point(102, 231);
            this.pictureBox35.Name = "pictureBox35";
            this.pictureBox35.Size = new System.Drawing.Size(67, 50);
            this.pictureBox35.TabIndex = 35;
            this.pictureBox35.TabStop = false;
            // 
            // pictureBox36
            // 
            this.pictureBox36.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar1;
            this.pictureBox36.Location = new System.Drawing.Point(102, 281);
            this.pictureBox36.Name = "pictureBox36";
            this.pictureBox36.Size = new System.Drawing.Size(67, 50);
            this.pictureBox36.TabIndex = 36;
            this.pictureBox36.TabStop = false;
            // 
            // pictureBox37
            // 
            this.pictureBox37.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar;
            this.pictureBox37.Location = new System.Drawing.Point(615, 473);
            this.pictureBox37.Name = "pictureBox37";
            this.pictureBox37.Size = new System.Drawing.Size(147, 50);
            this.pictureBox37.TabIndex = 37;
            this.pictureBox37.TabStop = false;
            // 
            // pictureBox38
            // 
            this.pictureBox38.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar;
            this.pictureBox38.Location = new System.Drawing.Point(767, 63);
            this.pictureBox38.Name = "pictureBox38";
            this.pictureBox38.Size = new System.Drawing.Size(156, 50);
            this.pictureBox38.TabIndex = 38;
            this.pictureBox38.TabStop = false;
            // 
            // pictureBox40
            // 
            this.pictureBox40.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar;
            this.pictureBox40.Location = new System.Drawing.Point(1028, 424);
            this.pictureBox40.Name = "pictureBox40";
            this.pictureBox40.Size = new System.Drawing.Size(88, 63);
            this.pictureBox40.TabIndex = 40;
            this.pictureBox40.TabStop = false;
            // 
            // pictureBox42
            // 
            this.pictureBox42.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar1;
            this.pictureBox42.Location = new System.Drawing.Point(1125, 231);
            this.pictureBox42.Name = "pictureBox42";
            this.pictureBox42.Size = new System.Drawing.Size(100, 50);
            this.pictureBox42.TabIndex = 42;
            this.pictureBox42.TabStop = false;
            // 
            // pictureBox43
            // 
            this.pictureBox43.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar1;
            this.pictureBox43.Location = new System.Drawing.Point(1125, 281);
            this.pictureBox43.Name = "pictureBox43";
            this.pictureBox43.Size = new System.Drawing.Size(100, 50);
            this.pictureBox43.TabIndex = 43;
            this.pictureBox43.TabStop = false;
            // 
            // pictureBox44
            // 
            this.pictureBox44.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar1;
            this.pictureBox44.Location = new System.Drawing.Point(1125, 330);
            this.pictureBox44.Name = "pictureBox44";
            this.pictureBox44.Size = new System.Drawing.Size(100, 50);
            this.pictureBox44.TabIndex = 44;
            this.pictureBox44.TabStop = false;
            // 
            // pictureBox45
            // 
            this.pictureBox45.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar1;
            this.pictureBox45.Location = new System.Drawing.Point(1125, 353);
            this.pictureBox45.Name = "pictureBox45";
            this.pictureBox45.Size = new System.Drawing.Size(100, 50);
            this.pictureBox45.TabIndex = 45;
            this.pictureBox45.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(96, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 48;
            this.label2.Text = "Café Rocher";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(83, 572);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 13);
            this.label3.TabIndex = 49;
            this.label3.Text = "Casa Embrujada";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(161, 414);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 13);
            this.label4.TabIndex = 50;
            this.label4.Text = "Casa Port";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label5.Location = new System.Drawing.Point(400, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 13);
            this.label5.TabIndex = 51;
            this.label5.Text = "Casa Paul";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label6.Location = new System.Drawing.Point(643, 37);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 13);
            this.label6.TabIndex = 52;
            this.label6.Text = "Casa Blanca";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label7.Location = new System.Drawing.Point(1077, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(133, 13);
            this.label7.TabIndex = 53;
            this.label7.Text = "Supermercado Lina";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label8.Location = new System.Drawing.Point(765, 116);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 13);
            this.label8.TabIndex = 54;
            this.label8.Text = "Banco Ayuda";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label9.Location = new System.Drawing.Point(454, 414);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 13);
            this.label9.TabIndex = 55;
            this.label9.Text = "Estación Policía";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label10.Location = new System.Drawing.Point(942, 39);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 13);
            this.label10.TabIndex = 56;
            this.label10.Text = "Casa Linda";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label11.Location = new System.Drawing.Point(1118, 498);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(132, 13);
            this.label11.TabIndex = 57;
            this.label11.Text = "C. Comercial Shean";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label12.Location = new System.Drawing.Point(765, 566);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 13);
            this.label12.TabIndex = 58;
            this.label12.Text = "Casa del Sol";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label13.Location = new System.Drawing.Point(521, 550);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(87, 13);
            this.label13.TabIndex = 59;
            this.label13.Text = "Tronchatoro";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label14.Location = new System.Drawing.Point(893, 276);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(109, 13);
            this.label14.TabIndex = 60;
            this.label14.Text = "Hacienda Frank";
            // 
            // De1a2
            // 
            this.De1a2.Location = new System.Drawing.Point(239, 55);
            this.De1a2.MaxLength = 5;
            this.De1a2.Name = "De1a2";
            this.De1a2.Size = new System.Drawing.Size(68, 20);
            this.De1a2.TabIndex = 82;
            this.De1a2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label25.Location = new System.Drawing.Point(236, 24);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(82, 26);
            this.label25.TabIndex = 81;
            this.label25.Text = "Café Rocher \r\n- Casa Paul";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // De2a3
            // 
            this.De2a3.Location = new System.Drawing.Point(520, 53);
            this.De2a3.MaxLength = 5;
            this.De2a3.Name = "De2a3";
            this.De2a3.Size = new System.Drawing.Size(68, 20);
            this.De2a3.TabIndex = 84;
            this.De2a3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label15.Location = new System.Drawing.Point(512, 9);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(86, 26);
            this.label15.TabIndex = 83;
            this.label15.Text = "Casa Paul \r\n- Casa Blanca";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // De12a13
            // 
            this.De12a13.Location = new System.Drawing.Point(17, 461);
            this.De12a13.MaxLength = 5;
            this.De12a13.Name = "De12a13";
            this.De12a13.Size = new System.Drawing.Size(68, 20);
            this.De12a13.TabIndex = 94;
            this.De12a13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label20.Location = new System.Drawing.Point(-1, 414);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(106, 26);
            this.label20.TabIndex = 93;
            this.label20.Text = "Casa Port \r\n- Casa Embrujada";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // De12a11
            // 
            this.De12a11.Location = new System.Drawing.Point(252, 334);
            this.De12a11.MaxLength = 5;
            this.De12a11.Name = "De12a11";
            this.De12a11.Size = new System.Drawing.Size(68, 20);
            this.De12a11.TabIndex = 96;
            this.De12a11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label21.Location = new System.Drawing.Point(236, 292);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(108, 26);
            this.label21.TabIndex = 95;
            this.label21.Text = "Casa Port \r\n- Estación Policía";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // De10a9
            // 
            this.De10a9.Location = new System.Drawing.Point(651, 554);
            this.De10a9.MaxLength = 5;
            this.De10a9.Name = "De10a9";
            this.De10a9.Size = new System.Drawing.Size(68, 20);
            this.De10a9.TabIndex = 100;
            this.De10a9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label23.Location = new System.Drawing.Point(642, 512);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(86, 26);
            this.label23.TabIndex = 99;
            this.label23.Text = "Tronchatoro \r\n- Casa del Sol";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // De11a9
            // 
            this.De11a9.Location = new System.Drawing.Point(660, 424);
            this.De11a9.MaxLength = 5;
            this.De11a9.Name = "De11a9";
            this.De11a9.Size = new System.Drawing.Size(68, 20);
            this.De11a9.TabIndex = 102;
            this.De11a9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Teal;
            this.label24.Location = new System.Drawing.Point(612, 394);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(112, 26);
            this.label24.TabIndex = 101;
            this.label24.Text = "Estación Policía - \r\nCasa del Sol";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // De6a9
            // 
            this.De6a9.Location = new System.Drawing.Point(673, 278);
            this.De6a9.MaxLength = 5;
            this.De6a9.Name = "De6a9";
            this.De6a9.Size = new System.Drawing.Size(68, 20);
            this.De6a9.TabIndex = 106;
            this.De6a9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.label27.Location = new System.Drawing.Point(638, 249);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(86, 26);
            this.label27.TabIndex = 105;
            this.label27.Text = "Banco Ayuda \r\n- Casa del Sol";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // De1a12
            // 
            this.De1a12.Location = new System.Drawing.Point(17, 245);
            this.De1a12.MaxLength = 5;
            this.De1a12.Name = "De1a12";
            this.De1a12.Size = new System.Drawing.Size(68, 20);
            this.De1a12.TabIndex = 114;
            this.De1a12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label31.Location = new System.Drawing.Point(14, 203);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(82, 26);
            this.label31.TabIndex = 113;
            this.label31.Text = "Café Rocher \r\n- Casa Port";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // De11a10
            // 
            this.De11a10.Location = new System.Drawing.Point(318, 493);
            this.De11a10.MaxLength = 5;
            this.De11a10.Name = "De11a10";
            this.De11a10.Size = new System.Drawing.Size(68, 20);
            this.De11a10.TabIndex = 122;
            this.De11a10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label35.Location = new System.Drawing.Point(306, 451);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(104, 26);
            this.label35.TabIndex = 121;
            this.label35.Text = "Estación Policía \r\n- Tronchatoro";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // De7a8
            // 
            this.De7a8.Location = new System.Drawing.Point(995, 498);
            this.De7a8.MaxLength = 5;
            this.De7a8.Name = "De7a8";
            this.De7a8.Size = new System.Drawing.Size(68, 20);
            this.De7a8.TabIndex = 126;
            this.De7a8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label37.Location = new System.Drawing.Point(942, 469);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(126, 26);
            this.label37.TabIndex = 125;
            this.label37.Text = "Hacienda Frank \r\n- C. Comercial Shean";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // De4a8
            // 
            this.De4a8.Location = new System.Drawing.Point(1203, 319);
            this.De4a8.MaxLength = 5;
            this.De4a8.Name = "De4a8";
            this.De4a8.Size = new System.Drawing.Size(68, 20);
            this.De4a8.TabIndex = 128;
            this.De4a8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label38.Location = new System.Drawing.Point(1177, 276);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(126, 26);
            this.label38.TabIndex = 127;
            this.label38.Text = "Supermercado Lina \r\n- C. Comercial Shean";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // De3a6
            // 
            this.De3a6.Location = new System.Drawing.Point(558, 191);
            this.De3a6.MaxLength = 5;
            this.De3a6.Name = "De3a6";
            this.De3a6.Size = new System.Drawing.Size(68, 20);
            this.De3a6.TabIndex = 130;
            this.De3a6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.label39.Location = new System.Drawing.Point(517, 162);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(90, 26);
            this.label39.TabIndex = 129;
            this.label39.Text = "Casa Blanca \r\n- Banco Ayuda";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // De3a5
            // 
            this.De3a5.Location = new System.Drawing.Point(807, 55);
            this.De3a5.MaxLength = 5;
            this.De3a5.Name = "De3a5";
            this.De3a5.Size = new System.Drawing.Size(68, 20);
            this.De3a5.TabIndex = 132;
            this.De3a5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.DimGray;
            this.label40.Location = new System.Drawing.Point(804, 13);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(82, 26);
            this.label40.TabIndex = 131;
            this.label40.Text = "Casa Blanca \r\n- Casa Linda";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox39
            // 
            this.pictureBox39.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandarT;
            this.pictureBox39.Location = new System.Drawing.Point(1028, 143);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(151, 89);
            this.pictureBox39.TabIndex = 39;
            this.pictureBox39.TabStop = false;
            // 
            // De6a4
            // 
            this.De6a4.Location = new System.Drawing.Point(1032, 225);
            this.De6a4.MaxLength = 5;
            this.De6a4.Name = "De6a4";
            this.De6a4.Size = new System.Drawing.Size(68, 20);
            this.De6a4.TabIndex = 108;
            this.De6a4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Maroon;
            this.label28.Location = new System.Drawing.Point(893, 221);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(124, 26);
            this.label28.TabIndex = 107;
            this.label28.Text = "Banco Ayuda \r\n- Supermercado Lina";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // De11a6
            // 
            this.De11a6.Location = new System.Drawing.Point(568, 342);
            this.De11a6.MaxLength = 5;
            this.De11a6.Name = "De11a6";
            this.De11a6.Size = new System.Drawing.Size(58, 20);
            this.De11a6.TabIndex = 136;
            this.De11a6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.DarkOrchid;
            this.label42.Location = new System.Drawing.Point(517, 313);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(106, 26);
            this.label42.TabIndex = 135;
            this.label42.Text = "Estación Polícía \r\n- Banco Ayuda";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // De2a11
            // 
            this.De2a11.Location = new System.Drawing.Point(303, 209);
            this.De2a11.MaxLength = 5;
            this.De2a11.Name = "De2a11";
            this.De2a11.Size = new System.Drawing.Size(58, 20);
            this.De2a11.TabIndex = 138;
            this.De2a11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.Teal;
            this.label43.Location = new System.Drawing.Point(270, 180);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(108, 26);
            this.label43.TabIndex = 137;
            this.label43.Text = "Casa Paul \r\n- Estación Policía";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar1;
            this.pictureBox1.Location = new System.Drawing.Point(401, 182);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.TabIndex = 139;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar1;
            this.pictureBox2.Location = new System.Drawing.Point(401, 137);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 50);
            this.pictureBox2.TabIndex = 140;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandarT;
            this.pictureBox16.Location = new System.Drawing.Point(673, 328);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(155, 89);
            this.pictureBox16.TabIndex = 16;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar;
            this.pictureBox5.Location = new System.Drawing.Point(850, 168);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(36, 50);
            this.pictureBox5.TabIndex = 142;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::wCaminoMinimoIO.Properties.Resources.CalleEstandar;
            this.pictureBox4.Location = new System.Drawing.Point(880, 168);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(156, 50);
            this.pictureBox4.TabIndex = 141;
            this.pictureBox4.TabStop = false;
            // 
            // btnCaminoMin
            // 
            this.btnCaminoMin.BackColor = System.Drawing.Color.SteelBlue;
            this.btnCaminoMin.Font = new System.Drawing.Font("Yu Gothic UI Light", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaminoMin.Location = new System.Drawing.Point(66, 3);
            this.btnCaminoMin.Name = "btnCaminoMin";
            this.btnCaminoMin.Size = new System.Drawing.Size(155, 30);
            this.btnCaminoMin.TabIndex = 143;
            this.btnCaminoMin.Text = "Camino Mínimo";
            this.btnCaminoMin.UseVisualStyleBackColor = false;
            this.btnCaminoMin.Click += new System.EventHandler(this.btnCaminoMin_Click);
            // 
            // De6a8
            // 
            this.De6a8.Location = new System.Drawing.Point(1048, 307);
            this.De6a8.MaxLength = 5;
            this.De6a8.Name = "De6a8";
            this.De6a8.Size = new System.Drawing.Size(68, 20);
            this.De6a8.TabIndex = 145;
            this.De6a8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(1013, 265);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 26);
            this.label1.TabIndex = 144;
            this.label1.Text = "Banco Ayuda \r\n- C. Comercial Shean";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblValida
            // 
            this.lblValida.AutoSize = true;
            this.lblValida.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValida.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblValida.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblValida.Location = new System.Drawing.Point(33, 50);
            this.lblValida.Name = "lblValida";
            this.lblValida.Size = new System.Drawing.Size(61, 17);
            this.lblValida.TabIndex = 146;
            this.lblValida.Text = "label16";
            this.lblValida.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnLimpiar);
            this.panel1.Controls.Add(this.btnCaminoMin);
            this.panel1.Controls.Add(this.lblValida);
            this.panel1.Location = new System.Drawing.Point(876, 572);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(404, 125);
            this.panel1.TabIndex = 147;
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.BackColor = System.Drawing.Color.SteelBlue;
            this.btnLimpiar.Font = new System.Drawing.Font("Yu Gothic UI Light", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiar.Location = new System.Drawing.Point(227, 3);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(111, 30);
            this.btnLimpiar.TabIndex = 147;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = false;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.lblResultado.Location = new System.Drawing.Point(212, 734);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(82, 25);
            this.lblResultado.TabIndex = 148;
            this.lblResultado.Text = "label16";
            // 
            // lblRuta
            // 
            this.lblRuta.AutoSize = true;
            this.lblRuta.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRuta.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.lblRuta.Location = new System.Drawing.Point(212, 772);
            this.lblRuta.Name = "lblRuta";
            this.lblRuta.Size = new System.Drawing.Size(82, 25);
            this.lblRuta.TabIndex = 149;
            this.lblRuta.Text = "label16";
            // 
            // lblPtoLlegada
            // 
            this.lblPtoLlegada.AutoSize = true;
            this.lblPtoLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPtoLlegada.ForeColor = System.Drawing.Color.Teal;
            this.lblPtoLlegada.Location = new System.Drawing.Point(212, 694);
            this.lblPtoLlegada.Name = "lblPtoLlegada";
            this.lblPtoLlegada.Size = new System.Drawing.Size(75, 22);
            this.lblPtoLlegada.TabIndex = 150;
            this.lblPtoLlegada.Text = "label16";
            // 
            // lblPtoPartida
            // 
            this.lblPtoPartida.AutoSize = true;
            this.lblPtoPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPtoPartida.ForeColor = System.Drawing.Color.Teal;
            this.lblPtoPartida.Location = new System.Drawing.Point(212, 659);
            this.lblPtoPartida.Name = "lblPtoPartida";
            this.lblPtoPartida.Size = new System.Drawing.Size(75, 22);
            this.lblPtoPartida.TabIndex = 151;
            this.lblPtoPartida.Text = "label16";
            // 
            // frmDijkstra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1315, 824);
            this.Controls.Add(this.lblPtoPartida);
            this.Controls.Add(this.lblPtoLlegada);
            this.Controls.Add(this.lblRuta);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.De6a8);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.De2a11);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.De11a6);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.De3a5);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.De3a6);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.De4a8);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.De7a8);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.De11a10);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.De1a12);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.De6a4);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.De6a9);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.De11a9);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.De10a9);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.De12a11);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.De12a13);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.De2a3);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.De1a2);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox45);
            this.Controls.Add(this.pictureBox44);
            this.Controls.Add(this.pictureBox43);
            this.Controls.Add(this.pictureBox42);
            this.Controls.Add(this.pictureBox40);
            this.Controls.Add(this.pictureBox39);
            this.Controls.Add(this.pictureBox38);
            this.Controls.Add(this.pictureBox37);
            this.Controls.Add(this.pictureBox36);
            this.Controls.Add(this.pictureBox35);
            this.Controls.Add(this.pictureBox34);
            this.Controls.Add(this.pictureBox33);
            this.Controls.Add(this.pictureBox29);
            this.Controls.Add(this.pictureBox27);
            this.Controls.Add(this.pictureBox26);
            this.Controls.Add(this.pictureBox25);
            this.Controls.Add(this.pictureBox24);
            this.Controls.Add(this.pictureBox23);
            this.Controls.Add(this.pictureBox22);
            this.Controls.Add(this.pictureBox21);
            this.Controls.Add(this.pictureBox20);
            this.Controls.Add(this.pictureBox19);
            this.Controls.Add(this.pictureBox18);
            this.Controls.Add(this.pictureBox17);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.CasaComercial);
            this.Controls.Add(this.CasaGris);
            this.Controls.Add(this.Mansion);
            this.Controls.Add(this.CasaPlus);
            this.Controls.Add(this.CasaPurpura);
            this.Controls.Add(this.CasaSeria);
            this.Controls.Add(this.CasaSol);
            this.Controls.Add(this.Casita);
            this.Controls.Add(this.Encantada);
            this.Controls.Add(this.Policia);
            this.Controls.Add(this.Tienda);
            this.Controls.Add(this.Banco);
            this.Controls.Add(this.Cafe);
            this.Name = "frmDijkstra";
            this.Text = "Camino Mínimo";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CasaComercial)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CasaGris)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Mansion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CasaPlus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CasaPurpura)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CasaSeria)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CasaSol)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Casita)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Encantada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Policia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tienda)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Banco)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cafe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Cafe;
        private System.Windows.Forms.PictureBox Banco;
        private System.Windows.Forms.PictureBox Tienda;
        private System.Windows.Forms.PictureBox Policia;
        private System.Windows.Forms.PictureBox Encantada;
        private System.Windows.Forms.PictureBox Casita;
        private System.Windows.Forms.PictureBox CasaSol;
        private System.Windows.Forms.PictureBox CasaSeria;
        private System.Windows.Forms.PictureBox CasaPurpura;
        private System.Windows.Forms.PictureBox CasaPlus;
        private System.Windows.Forms.PictureBox Mansion;
        private System.Windows.Forms.PictureBox CasaGris;
        private System.Windows.Forms.PictureBox CasaComercial;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.PictureBox pictureBox37;
        private System.Windows.Forms.PictureBox pictureBox38;
        private System.Windows.Forms.PictureBox pictureBox40;
        private System.Windows.Forms.PictureBox pictureBox42;
        private System.Windows.Forms.PictureBox pictureBox43;
        private System.Windows.Forms.PictureBox pictureBox44;
        private System.Windows.Forms.PictureBox pictureBox45;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox De1a2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox De2a3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox De12a13;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox De12a11;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox De10a9;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox De11a9;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox De6a9;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox De1a12;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox De11a10;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox De7a8;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox De4a8;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox De3a6;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox De3a5;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.TextBox De6a4;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox De11a6;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox De2a11;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button btnCaminoMin;
        private System.Windows.Forms.TextBox De6a8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblValida;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label lblRuta;
        private System.Windows.Forms.Label lblPtoLlegada;
        private System.Windows.Forms.Label lblPtoPartida;
        private System.Windows.Forms.Button btnLimpiar;
    }
}

